import { Component } from '@angular/core';
import { Course } from './course.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'myapp';
  headerImage:string ="https://raw.githubusercontent.com/dart-lang/logos/master/logos_and_wordmarks/angulardart-logo.png";
  //course1:Course =new Course ("Vue","0 days");
  //course2:Course =new Course("Node","10 days");
  //course3:Course =new Course("Angular","15 days");
  courses:Course[]=[new Course("Vue","20 days"),
  new Course("NodeJS","1 day"),
  new Course("Angular","40 days"),
  new Course("Web","100 days")]

  ChangeHeading () {
    this.title="Amazon";
  }
  ChangeHeadingOnChange (e) {
    this.title= e.target.value;
  }
}
