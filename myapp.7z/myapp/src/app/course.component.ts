import {Component, Input} from "@angular/core";
import { template } from '@angular/core/src/render3';
import { Course } from './course.model';
@Component({
    selector:`course`,
    templateUrl:'./course.component.html'
    
})
export class CourseComponent {
@Input() coursedetails:Course=new Course("React","100 days") ;
}
